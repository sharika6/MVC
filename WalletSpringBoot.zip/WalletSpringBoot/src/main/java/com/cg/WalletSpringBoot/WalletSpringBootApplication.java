package com.cg.WalletSpringBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WalletSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(WalletSpringBootApplication.class, args);
	}
}
